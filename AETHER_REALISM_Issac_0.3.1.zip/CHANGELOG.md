# Changes

## 0.3.1 — Issac Edition

- Brand the pack, main menu and README as AETHER REALISM by Issac.
- Add a Credits and Licence menu while retaining original copyright notices.
- Shader rendering and presets remain those validated for version 0.3.


## 0.3 — 2026-10-24

This is a new Noble-based project, replacing the previous Complementary-based
patch-kit approach for the user's redistribution and art-direction goals.
No Complementary code or Visual Redemption assets are included.

- Add an analytic multiband ocean field with matched height/derivative output.
- Add harmonic crest control and pixel-footprint wave filtering.
- Route host water normals, parallax and caustics through the new field.
- Revise water absorption/scattering, wave defaults and parallax quality.
- Fix uninitialised previous parallax height and bound the grazing denominator.
- Retune atmosphere, cloud coverage/detail, cloud shadows and water transport.
- Add a mild natural colour finish after the host tone mapping.
- Add Aether Realism, Fast and Capture profiles, and an identifiable menu label.
- Add an optional flat-normal diagnostic for comparison.
- Retain GPL and third-party notices; include editable shader source and credits.

Water optics, atmosphere, lighting, shadows, reflections, caustics, anti-aliasing,
PBR support and the general rendering pipeline are inherited from Noble.

Validation: 328/328 standard stages compiled; 1,024 GPU samples checked.
No Minecraft gameplay or photorealistic appearance claim has been verified.
