// Aether Realism, modified 2026-10-24. AI-assisted additions.
// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef AETHER_FINISH_FUNCTIONS
#define AETHER_FINISH_FUNCTIONS
vec3 aetherNaturalFinish(vec3 rgb) {
    // Applied after tone mapping: mild foliage restraint, cooler deep shade,
    // warm highlight separation. Effects are deliberately luminance-dependent.
    float y = dot(rgb, vec3(0.2126, 0.7152, 0.0722));
    float greenMask = smoothstep(0.0, 0.13, rgb.g - max(rgb.r, rgb.b));
    vec3 restrained = mix(rgb, vec3(y), greenMask * 0.13);
    float shadow = 1.0 - smoothstep(0.04, 0.40, y);
    float highlight = smoothstep(0.58, 0.95, y);
    restrained *= vec3(1.0) + shadow * vec3(-0.015, 0.003, 0.022)
                            + highlight * vec3(0.018, 0.004, -0.014);
    return clamp(mix(rgb, restrained, AETHER_FINISH), 0.0, 1.0);
}
#endif
