// Aether Realism, modified 2026-10-24. AI-assisted additions.
// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef AETHER_OCEAN_SPECTRUM
#define AETHER_OCEAN_SPECTRUM

// Returns height and its exact X/Z derivatives. Same field for normals,
// parallax and caustics; footprint smoothly removes subpixel wave bands.
vec3 aetherOceanField(vec2 p, float t, int octaves, float footprint) {
    vec3 field = vec3(0.0);
    float heightScale = 0.16 * WAVE_AMPLITUDE * 0.5;
    float waveNumber = 6.28318530718 / max(WAVE_LENGTH, 0.5);
    float directionAngle = radians(WAVE_ANGLE);
    for (int i = 0; i < min(octaves, 16); ++i) {
        float band = float(i);
        float angle = directionAngle + band * 2.39996323;
        vec2 direction = vec2(cos(angle), sin(angle));
        float k = waveNumber * pow(1.72, band);
        float amplitude = heightScale * pow(0.55, band);
        float filtered = 1.0 - smoothstep(0.65, 2.40, k * footprint);
        float phase = dot(p, direction) * k - sqrt(9.81 * k) * t;
        float harmonic = AETHER_CHOP * 0.18;
        float h = sin(phase) + harmonic * sin(2.0 * phase);
        float dh = cos(phase) + 2.0 * harmonic * cos(2.0 * phase);
        field += vec3(h, direction * k * dh) * amplitude * filtered;
    }
    return field;
}
#endif
