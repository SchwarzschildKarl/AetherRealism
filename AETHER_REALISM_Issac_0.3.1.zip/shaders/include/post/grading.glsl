/********************************************************************************/
/*                                                                              */
/*    Noble Shaders                                                             */
/*    Copyright (C) 2026  Belmu                                                 */
/*                                                                              */
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.    */
/*                                                                              */
/********************************************************************************/

/*
    [References]:
        Uchimura, H. (2017). HDR Theory and practice. https://www.slideshare.net/nikuque/hdr-theory-and-practicce-jp
        Uchimura, H. (2017). GT Tonemap. https://www.desmos.com/calculator/gslcdxvipg?lang=fr
        Hable, J. (2017). Minimal Color Grading Tools. http://filmicworlds.com/blog/minimal-color-grading-tools/
        Taylor, M. (2019). Tone Mapping. https://64.github.io/tonemapping/
        Wikipedia. (2023). Von Kries coefficient law. https://en.wikipedia.org/wiki/Von_Kries_coefficient_law
        Wikipedia. (2023). LMS color space. https://en.wikipedia.org/wiki/LMS_color_space
        Wrensch, B. (2023). MINIMAL AGX IMPLEMENTATION. https://iolite-engine.com/blog_posts/minimal_agx_implementation
*/

//////////////////////////////////////////////////////////
/*--------------- TONEMAPPING OPERATORS ----------------*/
//////////////////////////////////////////////////////////

void whitePreservingReinhard(inout vec3 color, float white) {
    float luminance           = luminanceBT709(color);
    float toneMappedLuminance = luminance * (1.0 + luminance / (white * white)) / (1.0 + luminance);

    color *= toneMappedLuminance / luminance;
}

void reinhardJodie(inout vec3 color) {
    float luminance = luminanceBT709(color);
    vec3  tv        = color / (1.0 + color);

    color = mix(color / (1.0 + luminance), tv, tv);
}

void lottes(inout vec3 color) {
    const vec3 a      = vec3(1.6);   // Contrast
    const vec3 d      = vec3(0.977); // Shoulder contrast
    const vec3 hdrMax = vec3(8.0);   // White point
    const vec3 midIn  = vec3(0.18);
    const vec3 midOut = vec3(0.267);

    const vec3 b =
        (-pow(midIn, a) + pow(hdrMax, a) * midOut) /
        ((pow(hdrMax, a * d) - pow(midIn, a * d)) * midOut);

    const vec3 c =
        (pow(hdrMax, a * d) * pow(midIn, a) - pow(hdrMax, a) * pow(midIn, a * d) * midOut) /
        ((pow(hdrMax, a * d) - pow(midIn, a * d)) * midOut);

    color = pow(color, a) / (pow(color, a * d) * b + c);
}

vec3 uchimura(vec3 x, float P, float a, float m, float l, float c, float b) {
    float l0 = ((P - m) * l) / a;
    float L0 = m - m / a;
    float L1 = m + (1.0 - m) / a;
    float S0 = m + l0;
    float S1 = m + a * l0;
    float C2 = (a * P) / (P - S1);
    float CP = -C2 / P;

    vec3 w0 = vec3(1.0 - smoothstep(0.0, m, x));
    vec3 w2 = vec3(step(m + l0, x));
    vec3 w1 = vec3(1.0 - w0 - w2);

    vec3 T = vec3(m * pow(x / m, vec3(c)) + b);
    vec3 S = vec3(P - (P - S1) * exp(CP * (x - S0)));
    vec3 L = vec3(m + a * (x - m));

    return T * w0 + L * w1 + S * w2;
}

void uchimura(inout vec3 color) {
    const float P = 1.0;  // max display brightness
    const float a = 1.0;  // contrast
    const float m = 0.22; // linear section start
    const float l = 0.4;  // linear section length
    const float c = 1.33; // black
    const float b = 0.0;  // pedestal

    color = uchimura(color, P, a, m, l, c, b);
}

void uncharted2(inout vec3 color) {
    const float A = 0.15;
    const float B = 0.50;
    const float C = 0.10;
    const float D = 0.20;
    const float E = 0.02;
    const float F = 0.30;
    const float W = 11.2;

    float white = ((W * (A * W + C * B) + D * E) / (W * (A * W + B) + D * F)) - E / F;

    color  = ((color * (A * color + C * B) + D * E) / (color * (A * color + B) + D * F)) - E / F;
    color /= white;
}

void burgess(inout vec3 color) {
    vec3 maxColor = max(vec3(0.0), color - 0.004);
    
    color = (maxColor * (6.2 * maxColor + 0.05)) / (maxColor * (6.2 * maxColor + 2.3) + 0.06);
}

const mat3 agxTransform = mat3(
    0.8424010709504686, 0.0424010709504685, 0.04240107095046854,
    0.0784365015618027, 0.8784365015618028, 0.07843650156180276,
    0.0791624274877287, 0.0791624274877287, 0.87916242748772870
);

const mat3 agxTransformInverse = mat3(
     1.19699866131191430, -0.05300133868808567, -0.05300133868808567,
    -0.09804562695225345,  1.15195437304774660, -0.09804562695225345,
    -0.09895303435966087, -0.09895303435966087,  1.15104696564033900
);

// Analytical solution from GeForceLegend (https://github.com/GeForceLegend)
vec3 agxDefaultContrastAnalytical(vec3 x) {
    const float scale0 = 59.507875;
    const float scale1 = 69.862789;

    x -= 20.0 / 33.0;
    vec3 type = vec3(floatBitsToUint(x) >> 31);

    vec3 scale = scale1 + (scale0 - scale1) * type;
    vec3 power0 = 13.0 / 4.0 - 0.25 * type;
    vec3 power1 = -4.0 / 13.0 + (4.0 / 13.0 - 1.0 / 3.0) * type;

    x = 2.0 * x * pow(1.0 + scale * pow(abs(x), power0), power1) + 0.5;
    return x;
}

void agx(inout vec3 color) {
    const float minEv = -12.47393;
    const float maxEv =  4.026069;

    // Input transform
    color = maxEps(agxTransform * color);

    // Log2 space encoding
    color = clamp(log2(color), minEv, maxEv);
    color = (color - minEv) / (maxEv - minEv);

    // Apply sigmoid function approximation
    color = agxDefaultContrastAnalytical(color);
}

void agxEotf(inout vec3 color) {
    // Inverse input transform
    color = agxTransformInverse * color;
}

void agxLook(inout vec3 color) {
    
    #if AGX_LOOK == 0

        // Default
        const vec3  slope      = vec3(1.0);
        const vec3  power      = vec3(1.0);
        const float saturation = 1.1;

    #elif AGX_LOOK == 1

        // Golden
        const vec3  slope      = vec3(1.0, 0.9, 0.5);
        const vec3  power      = vec3(0.8);
        const float saturation = 0.8;

    #elif AGX_LOOK == 2

        // Punchy
        const vec3  slope      = vec3(1.0);
        const vec3  power      = vec3(1.1);
        const float saturation = 1.2;

    #endif

    float luma = luminanceBT709(color);
  
    color = pow(color * slope, power);
    color = luma + saturation * (color - luma);
}

//////////////////////////////////////////////////////////
/*----------------------- GRADING ----------------------*/
//////////////////////////////////////////////////////////

mat3 chromaticAdaptationMatrix(vec3 source, vec3 destination) {
    vec3 sourceLMS      = source * CONE_RESP_CAT02;
    vec3 destinationLMS = destination * CONE_RESP_CAT02;

    vec3 tmp = destinationLMS / sourceLMS;

    mat3 vonKries = mat3(
        tmp.x, 0.0, 0.0,
        0.0, tmp.y, 0.0,
        0.0, 0.0, tmp.z
    );

    return (CONE_RESP_CAT02 * vonKries) * CONE_RESP_CAT02_INV;
}

void whiteBalance(inout vec3 color) {
    vec3 source      = toXYZ(blackbody(WHITE_BALANCE));
    vec3 destination = toXYZ(blackbody(WHITE_POINT  ));

    color *= chromaticAdaptationMatrix(source, destination);
}

void vibrance(inout vec3 color, float intensity) {
    float minimum = minOf(color);
    float maximum = maxOf(color);

    float saturation = (1.0 - saturate(maximum - minimum)) * saturate(1.0 - maximum) * luminanceBT709(color) * 5.0;
    vec3  lightness  = vec3((minimum + maximum) * 0.5);

    // Vibrance
    color = mix(color, mix(lightness, color, intensity), saturation);
    // Negative vibrance
    color = mix(color, lightness, (1.0 - lightness) * (1.0 - intensity) * 0.5 * abs(intensity));
}

void saturation(inout vec3 color, float intensity) {
    color = mix(vec3(luminanceBT709(color)), color, intensity);
}

void contrast(inout vec3 color, float contrast) {
    color = max0((color - 0.5) * contrast + 0.5);
}

void liftGammaGain(inout vec3 color, float lift, float gamma, float gain) {
    vec3 lerpV = pow(color, vec3(gamma));
    color = gain * lerpV + lift * (1.0 - lerpV);
}
