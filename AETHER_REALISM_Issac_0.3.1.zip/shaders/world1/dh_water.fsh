#version 430 compatibility

#define PROGRAM_WATER
#define STAGE_FRAGMENT
#define WORLD_END

#include "/programs/gbuffers/dh/dh_forward.glsl"
