from egl_compiler import compile, G
from pathlib import Path
import re, sys, json
root=Path(sys.argv[1]).resolve()
files={p.relative_to(root).as_posix():p.read_text(errors='replace') for p in root.rglob('*') if p.suffix in ['.glsl','.fsh','.vsh','.csh']}
cache={}
def expand(path,stack=()):
 if path in cache:return cache[path]
 if path in stack:raise ValueError('Include cycle '+path)
 if path not in files:raise ValueError('Missing include '+path)
 def include(m):
  ref=m[1]
  target=ref.lstrip('/') if ref.startswith('/') else str(Path(path).parent/ref)
  return expand(target,stack+(path,))
 s=re.sub(r'^\s*#include\s+"([^"]+)"[^\n]*$',include,files[path],flags=re.M)
 cache[path]=s
 return s
failed=[];passed=[]
for path in sorted(files):
 if not re.match(r'world(?:0|1|-1)/',path) or not path.endswith(('.fsh','.vsh','.csh')):continue
 # Optional mod/integration entrypoints need their respective host injections.
 if any(x in path for x in ['voxy','dh_','clrwl']):continue
 code=expand(path);pos=code.index('\n')
 code=code[:pos+1]+'#define MC_VERSION 12100\n#define MC_GL_VERSION 450\n#define MC_OS_LINUX\n#define IS_IRIS 1\n#define MC_HAND_DEPTH 0.125\n'+code[pos+1:]
 kind={'.fsh':0x8B30,'.vsh':0x8B31,'.csh':0x91B9}[Path(path).suffix]
 ok,log=compile(code,kind)
 if ok:passed.append(path)
 else:
  failed.append({'path':path,'log':log})
  Path('failed-'+path.replace('/','-')).write_text(code)
print('Compiled',len(passed),'/',len(passed)+len(failed))
for err in failed[:8]:print(err['path'],err['log'][:1000])
Path('shader-compile-results.json').write_text(json.dumps({'passed':passed,'failed':failed},indent=2))
sys.exit(bool(failed))
