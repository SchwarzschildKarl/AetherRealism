import ctypes as C
from pathlib import Path
import numpy as np
from egl_compiler import G,sig,I,U,P,S
source=Path('shaders/include/aether/ocean_spectrum.glsl').read_text()
source2=Path('shaders/include/aether/finish.glsl').read_text()
code='''#version 430
#define WAVE_AMPLITUDE 2.0
#define WAVE_LENGTH 8.0
#define WAVE_ANGLE 15.0
#define AETHER_CHOP 1.0
#define AETHER_FINISH 1.0
'''+source+'\n'+source2+'''
layout(local_size_x=64) in;
layout(std430,binding=0) buffer Results { vec4 outData[]; };
void main(){
 uint i=gl_GlobalInvocationID.x;
 vec2 p=vec2(float(i%32u)*0.71,float(i/32u)*0.61);
 float t=3.7;
 vec3 f=aetherOceanField(p,t,12,0.01);
 float e=0.001;
 float dx=(aetherOceanField(p+vec2(e,0),t,12,0.01).x-aetherOceanField(p-vec2(e,0),t,12,0.01).x)/(2.0*e);
 float dz=(aetherOceanField(p+vec2(0,e),t,12,0.01).x-aetherOceanField(p-vec2(0,e),t,12,0.01).x)/(2.0*e);
 outData[i*3u]=vec4(f,0);
 outData[i*3u+1u]=vec4(dx,dz,aetherOceanField(p,t,12,20.0).y,0);
 outData[i*3u+2u]=vec4(aetherNaturalFinish(vec3(float(i)/1023.0,0.5,0.3)),1);
}
'''
sig(G,'glCreateProgram',U,[]);sig(G,'glAttachShader',None,[U,U]);sig(G,'glLinkProgram',None,[U]);sig(G,'glGetProgramiv',None,[U,U,C.POINTER(I)]);sig(G,'glUseProgram',None,[U]);sig(G,'glGenBuffers',None,[I,C.POINTER(U)]);sig(G,'glBindBuffer',None,[U,U]);sig(G,'glBufferData',None,[U,C.c_ssize_t,P,U]);sig(G,'glBindBufferBase',None,[U,U,U]);sig(G,'glDispatchCompute',None,[U,U,U]);sig(G,'glMemoryBarrier',None,[U]);sig(G,'glGetBufferSubData',None,[U,C.c_ssize_t,C.c_ssize_t,P]);sig(G,'glGetProgramInfoLog',None,[U,I,C.POINTER(I),P])
sh=G.glCreateShader(0x91B9);s=S(code.encode());G.glShaderSource(sh,1,C.byref(s),None);G.glCompileShader(sh);ok=I();G.glGetShaderiv(sh,0x8B81,C.byref(ok));assert ok.value
pr=G.glCreateProgram();G.glAttachShader(pr,sh);G.glLinkProgram(pr);G.glGetProgramiv(pr,0x8B82,C.byref(ok));assert ok.value
b=U();G.glGenBuffers(1,C.byref(b));G.glBindBuffer(0x90D2,b);a=np.zeros((1024,3,4),dtype=np.float32);G.glBufferData(0x90D2,a.nbytes,None,0x88E8);G.glBindBufferBase(0x90D2,0,b);G.glUseProgram(pr);G.glDispatchCompute(16,1,1);G.glMemoryBarrier(0xFFFFFFFF);G.glGetBufferSubData(0x90D2,0,a.nbytes,a.ctypes.data_as(P))
assert np.isfinite(a).all()
err=np.abs(a[:,0,1:3]-a[:,1,:2]).max()
assert err<0.012,err
assert np.std(a[:,0,1:3])>0.035
assert np.max(np.abs(a[:,1,2]))<1e-5
assert np.min(a[:,2,:3])>=0 and np.max(a[:,2,:3])<=1
print('PASS: GPU execution on 1024 samples; finite height/normal/grading, derivative error',round(float(err),6),'and subpixel-wave filtering verified.')
print('Wave height range:',float(a[:,0,0].min()),float(a[:,0,0].max()),'slope RMS:',float(np.sqrt(np.mean(a[:,0,1:3]**2))))
