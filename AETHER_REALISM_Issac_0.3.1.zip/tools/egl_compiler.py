import ctypes as C
from pathlib import Path
import re, sys, zipfile

E=C.CDLL('libEGL.so.1'); G=C.CDLL('libGL.so.1')
def sig(lib,name,rest,args):
 f=getattr(lib,name); f.restype=rest; f.argtypes=args; return f
P=C.c_void_p; I=C.c_int; U=C.c_uint; S=C.c_char_p
sig(E,'eglGetProcAddress',P,[S])
getplat=C.CFUNCTYPE(P,U,P,C.POINTER(I))(E.eglGetProcAddress(b'eglGetPlatformDisplayEXT'))
dpy=getplat(0x31DD,None,None)
sig(E,'eglInitialize',U,[P,C.POINTER(I),C.POINTER(I)])
a,b=I(),I(); assert E.eglInitialize(dpy,C.byref(a),C.byref(b))
sig(E,'eglBindAPI',U,[U]); assert E.eglBindAPI(0x30A2)
sig(E,'eglChooseConfig',U,[P,C.POINTER(I),C.POINTER(P),I,C.POINTER(I)])
attrs=(I*7)(0x3040,0x0008,0x3033,0x0001,0x3024,8,0x3038)
config=P(); n=I(); assert E.eglChooseConfig(dpy,attrs,C.byref(config),1,C.byref(n)) and n.value
sig(E,'eglCreateContext',P,[P,P,P,C.POINTER(I)])
ctx=E.eglCreateContext(dpy,config,None,(I*1)(0x3038)); assert ctx
sig(E,'eglMakeCurrent',U,[P,P,P,P]); assert E.eglMakeCurrent(dpy,None,None,ctx)
sig(G,'glGetString',S,[U]); print('Compiler:',G.glGetString(0x1F02).decode())
sig(G,'glCreateShader',U,[U]); sig(G,'glShaderSource',None,[U,I,C.POINTER(S),C.POINTER(I)])
sig(G,'glCompileShader',None,[U]); sig(G,'glGetShaderiv',None,[U,U,C.POINTER(I)])
sig(G,'glGetShaderInfoLog',None,[U,I,C.POINTER(I),P]); sig(G,'glDeleteShader',None,[U])

def compile(code,kind=0x8B30):
 shader=G.glCreateShader(kind); s=S(code.encode()); G.glShaderSource(shader,1,C.byref(s),None)
 G.glCompileShader(shader); ok=I(); G.glGetShaderiv(shader,0x8B81,C.byref(ok))
 buf=C.create_string_buffer(32768); G.glGetShaderInfoLog(shader,len(buf),None,buf); G.glDeleteShader(shader)
 return bool(ok.value),buf.value.decode()

