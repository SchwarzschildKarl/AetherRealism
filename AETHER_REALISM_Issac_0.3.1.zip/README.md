# AETHER REALISM

**Issac Edition · 0.3.1**

A shader project edition by **Issac**, aimed at natural daylight, reflective
water, layered clouds and atmospheric landscapes. This is an **AI-assisted fork
of [Noble by Belmu](https://github.com/BelmuTM/Noble)**, not an independently
written rendering engine. Visual Redemption for Red Dead Redemption II is an
art-direction reference only. No Visual Redemption code, textures, branding or
screenshots are included, and this project is not affiliated with its creators.

## Install — no patcher or Python required

Put **AETHER_REALISM_Issac_0.3.1.zip** directly in your Minecraft instance's
`shaderpacks` folder. Launch Minecraft Java with Iris and select
**AETHER_REALISM_Issac_0.3.1** in Video Settings → Shader Packs.

This pack includes its base. You do not need Complementary, the previous Aether
Waters kit, or a separate Noble download. Select the new pack explicitly; the
old pack remains separate. Open Shader Pack Settings: the top row should say
**AETHER REALISM 0.3.1: Issac Edition**. That confirms you selected this build.

Choose **Aether Realism** from the profile selector. This is also the starting
configuration. Use **Aether Fast** if performance is poor. **Aether Capture**
increases quality and GPU cost for screenshots; it is not an FPS promise.
Leave **Flat Water Comparison OFF** to see the custom water normals.

Upstream targets Minecraft Java 1.16+ with Iris or OptiFine, on Windows/Linux
with an appropriate NVIDIA/AMD GPU. This fork was compiled using a 1.21 macro
and Iris-style feature defines; it has not been tested in either loader.
OpenGL 4.3 features are used. macOS and Bedrock are not supported by this build.
Start with 12–16 chunks render distance and no other graphics modifications.

## What is different

**New water wave field.** An analytic wave spectrum combines up to sixteen
crossing directions with sharpened crests and smooth filtering based on pixel
footprint. Water normals, parallax heights and caustics use the same wave
field. The wave field uses no Complementary water code. It changes surface
shading rather than adding mesh tessellation, fluid simulation, ocean surf or
world geometry. Reflections, refraction, physical water transport and caustic
rendering are inherited from Noble.

**Clearer water transport.** Revised absorption and scattering coefficients
reduce the base's murkiness, attenuate red more quickly than blue, and retain
water depth cues. This is a spectral approximation in RGB, not measured water
chemistry. The parallax refinement also gets a safe grazing denominator and
an initialised previous height.

**Atmosphere and clouds.** Noble's physical atmosphere and volumetric cloud
renderer form the foundation. Defaults increase atmospheric integration
quality, cloud detail, coverage and cloud-shadow quality, while retaining
weather changes. Haze remains restrained rather than acting as a uniform
colour overlay.

**Natural finish.** A small post-tone-map operation restrains very strong
foliage greens, adds a faint cool bias to deep shade, and a faint warm bias to
highlights. AgX, neutral daylight, restrained sharpening and slightly lower
saturation form the starting point. These choices aim toward the reference's
natural photographic style, rather than recreating another game's renderer.

All other major rendering systems come from Noble. See `CHANGELOG.md` and
`PROVENANCE.json` for exact scope. Original copyright and third-party notices
are retained.

## Aether controls

Shader Pack Settings → **Aether Realism**:

| Setting | Start here | Effect |
| --- | --- | --- |
| Custom Ocean Spectrum | On | Uses the new wave field; off restores Noble waves |
| Ocean Crest Sharpness | 1.0 | Controls harmonic crests |
| Natural Colour Finish | 1.0 | Controls the subtle final colour operation |
| Flat Water Comparison | Off | On flattens water normals for an A/B check |

Existing Noble water controls still provide wave speed, scale, strength,
parallax, caustics, absorption and scattering. Do not assume Aether Waters
0.1's settings apply: this is a different rendering pipeline.

## Photorealism and testing

Shaders change lighting and surface shading; they do not replace Minecraft's
block geometry, textures or vegetation models. A compatible PBR resource pack
can further change material appearance, but none is included or required.

**This is an experimental build, not a visually verified release.** All 328
standard fragment, vertex and compute shader stages compiled on Mesa OpenGL
4.5. The new ocean/grading code also executed on a software GPU with 1,024
sample points; finite values, analytic derivatives and wave filtering were
checked. These checks do not establish in-game appearance, Iris runtime
behaviour, hardware compatibility or performance.

Test the same scene at noon, dawn, sunset, night and in rain. Include a shallow
beach, deep water, underwater views, forests and caves. Check cloud motion,
reflection gaps and temporal shimmer before presenting screenshots as a
release showcase. Test optional LOD/mod integrations separately.

## Share on GitHub or with friends

This ZIP is both the installable pack and its editable source distribution.
To put it on GitHub, extract it and upload the **contents** to a repository so
`shaders/`, `LICENSE.txt`, and this README are at its root. Use a description
such as:

> AETHER REALISM — Issac Edition. Experimental Minecraft Java shader pack
> based on Noble by Belmu. Adds a
> custom ocean wave spectrum, revised water transport and natural colour
> grading. AI-assisted development; inspired by photographic landscape lighting.

Keep `LICENSE.txt`, source, upstream copyright headers, third-party notices,
and the attribution in this README. Identify your changes when making later
versions. The fork is distributed under **GPLv3 or later**, with retained
third-party notices for components such as ACES. Source files are supplied in
this ZIP. Do not describe it as Visual Redemption, as an official Noble release,
or as entirely original work.

You may send the complete ZIP to friends with these notices and source intact.
No GitHub repository has been created or published on your behalf.

## Provenance and developer tools

Base: https://github.com/BelmuTM/Noble

Base commit: `60fed66056e0d6ff4610618356a95b9e6a363e16`.

Modified: 2026-10-24, with AI-assisted code and tuning.

`tools/check_shaders.py shaders` runs standalone compilation on a Linux machine
with Mesa EGL/OpenGL. `tools/test_ocean_gpu.py` additionally requires NumPy.
Run both from the extracted repository root. Neither is needed to play.
The upstream helper script is retained in `upstream_scripts/`. The upstream
README is kept for reference under `docs/`; its screenshot paths refer to the
original Noble repository, not this fork. No showcase images are supplied.

## Edition branding

The project edition and public pack branding are **AETHER REALISM by Issac**.
Original authors retain ownership of their contributions. This attribution
does not claim that Issac wrote Noble or owns its original rendering engine.
